<svelte:head>
<html lang="en">
    <title>Kontakt meg!</title>
</svelte:head>


<script>
    import monke from 'images/monki-flip-monkey.gif'
import discord from 'images/discord.png'
import email from 'images/gmail.png'
import telephone from 'images/phone.png'
import monkeIcon from 'images/monke.jpg'
import snapchat from 'images/snapchat.png'
import balance from 'images/balance.png'
import golira from 'images/golira.png'
import lastbanana from 'images/lastbanana.jpg'
import POVBanana from 'images/POVBanana.jpg'
import vibe from 'images/vibe.jfif'

let Value=""




const visDiscord = () => {
    Value = "Discord"
}
const visMail = () => {
    Value = "Mail"
}
const visTLF = () => {
    Value = "TLF"
}
const visSnap = () => {
    Value = "Snap"
}
const visMonke = () => {
    Value = "Monke"
}

</script>
<style>
    .container{
        width:100;
        height:70%;
    }
    .header{
        font-size:18px;
        margin:auto;
        width:100%;
    }
    .midt{
        text-align:center;
        margin-top:10px;
    }
    .bar{
        background-color: black;
        width:20%;
        height:20px;
        margin:auto;
    }
    .Kontakt{
        width:19%;
        margin:1%;
        background:linear-gradient(0.375turn, #ABD699, #75C9B7);
    }
    .Kontakt img {
        margin-top:-20px;
    }
    img{
        padding:5px;
        width:50px;
    }
    .containerKontakt{
        display: flex;
        margin-top:80px;
    }
    .kontaktButton {
        width:100%;
        height:20%;
        margin:auto;
        background-color: #C7DDCC;
        text-align:center;
        border-radius: 5px;
    }
    .Info{
        width:60%;
        margin:auto;
        text-align:center
    }
    .header span {
        text-decoration:overline underline;
    }
    .infoContainer {
        background:linear-gradient(0.375turn, #ABD699, #75C9B7);
        width:98%;
        margin:1%;
    }

</style>





<div class="container">
    <div class="header"><h1>Ikke vær redd for å kontakte <span><b>TEODOR INC. LLC. AS</b></span></h1></div>
    <div class="bar">bar</div>
    <div class="midt"><h1>Mandag - Mandag: 07:00 - 07:01 (GMT+1)</h1></div>
    <div class="containerKontakt">
        <div class="discordKontakt Kontakt"><div class="Info"><img alt="Discord Icon" src={discord}><br><span><b>Discord</b></span><div class="kontaktButton"><a on:click={visDiscord}>DM me</a></div></div></div>
        <div class="emailKontakt Kontakt"><div class="Info"><img alt="Gmail Icon" src={email}><br><span><b>Gmail</b></span><div class="kontaktButton"><a on:click={visMail}>Send mail</a></div></div></div>
        <div class="tlfKontakt Kontakt"><div class="Info"><img alt="TLF Icon" src={telephone}><br><span><b>Telefon</b></span><div class="kontaktButton"><a on:click={visTLF}>RING MEG PÅ tlf</a></div></div></div>
        <div class="snapchatKontakt Kontakt"><div class="Info"><img alt="Snapchat Icon" src={snapchat}><br><span><b>Snapchat</b></span><div class="kontaktButton"><a on:click={visSnap}>Snap meg eller no idk</a></div></div></div>
        <div class="monke Kontakt"><div class="Info"><img alt="MONKE" src={monke}><br><span><b>MONKE</b></span><div class="kontaktButton"><a on:click={visMonke}>More monkey</a></div></div></div>
    </div>
    <div class="infoContainer">
        {#if Value === "Discord"}
            balls in yo jaws
            <br>
            <span>Discorden min er Teodor#9144</span>
        {:else if Value === "Mail"}
            balls in other persons jaw
            <br>
            Kontakt meg via <span>tebjorvik@elev.rogfk.no</span>
            Eller teovirksomhet@gmail.com
        {:else if Value === "TLF"}
            bro who the frick uses phone CRINGE
            <br>
            anyway nummeret mitt er 900 62 363
        {:else if Value === "Snap"}
            idk i forgor :skull:
        {:else if Value === "Monke"}
            <img alt="balance" src="{balance}">
            <img alt="golira" src="{golira}">
            <img alt="lastbanana" src="{lastbanana}">
            <img alt="pov banana" src="{POVBanana}">
            <img alt="vibing monke" src="{vibe}">
            <img alt="monke icon" src="{monkeIcon}">
        {:else}
            <b>no balls</b> <img style="margin-bottom:-11px;" alt="funny emote from wtithwudjiwjkjdnjihujnkihbnjihbjnkihbjnihbjn" src="https://www.streamscheme.com/wp-content/uploads/2022/02/sadge-200.png">
        {/if}
    </div>
</div>

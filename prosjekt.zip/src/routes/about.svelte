<svelte:head>
	<title>About</title>
</svelte:head>
<script>
import monke from 'images/gaming_monke.jpg'

let birthdate = new Date("04/05/2004")
var today = new Date();
var time = String(today.getTime());
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();

var today = new Date(mm + '/' + dd + '/' + yyyy);
console.log(today);
console.log(time);
console.log(birthdate);
console.log(today.getTime());
console.log(birthdate.getTime());
var Age_Difference_In_Time = time - (birthdate.getTime()+2820000);
let Age_Difference_In_Days = (Age_Difference_In_Time / (1000 * 3600 * 24*365));
console.log(Age_Difference_In_Time);
console.log(Age_Difference_In_Days);

var date1 = new Date("04/05/2022")

// To calculate the time difference of two dates
var Difference_In_Time = date1.getTime() - today.getTime();
  
// To calculate the no. of days between two dates
let Difference_In_Days = Math.ceil(Difference_In_Time / (1000 * 3600 * 24));

//To display the final no. of days (result)	
console.log("Total number of days between dates  <br>"
               + date1 + "<br> and <br>" 
               + today + " is: <br> " 
               + Difference_In_Days);
</script>
<h1>About</h1>

<p>HALLO! Jeg heter Teodor og er {Age_Difference_In_Days} år gammel, det er {Difference_In_Days} dager til jeg blir ett år eldre.
<br> Dette er sånn jeg ser ut:<br>
<img alt="me" src="{monke}"></p>